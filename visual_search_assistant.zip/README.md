
# Visual Search Assistant (Full Stack)

Run backend and frontend as separate services.
