
# Visual Search Assistant — Frontend (React)

## Setup
```bash
cd frontend
npm install
npm start
```
Dev server: http://localhost:3000
